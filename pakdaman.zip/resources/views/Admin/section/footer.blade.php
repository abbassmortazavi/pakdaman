<footer class="footer">
    <div class="container">
        <div class="row align-items-center flex-row-reverse">
            <div class="col-md-12 col-sm-12 text-center">
                حق نشر © 1401 <a href="javascript:void(0)">Sash</a>. طراحی شده با <span
                    class="fa fa-heart text-danger"></span> توسط <a href="javascript:void(0)"> استودیو لیمو </a>
                کلیه حقوق محفوظ است.
            </div>
        </div>
    </div>
</footer>
