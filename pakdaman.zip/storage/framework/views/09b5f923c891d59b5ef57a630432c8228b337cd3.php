<?php $__env->startSection('content'); ?>
    <div class="side-app">

        <div class="main-container container-fluid">

            <div class="page-header">
                <h1 class="page-title">لیست کالا</h1>
                <div>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">صفحه اصلی</a></li>
                        <li class="breadcrumb-item active" aria-current="page">داشبورد 01</li>
                    </ol>
                </div>
            </div>


            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>ردیف</th>
                    <th>نام</th>
                </tr>
                </thead>
                <tbody>
                </tbody>
            </table>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(function () {

            let table = $('.table').DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('commodities.index')); ?>",
                columns: [
                    {data: 'id', name: 'id'},
                    {data: 'name', name: 'name'},
                ]
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/Admin/commodities/index.blade.php ENDPATH**/ ?>