<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="rtl">
<head>
    <?php $baseUrl = url('/');?>
    <meta charset="UTF-8">
    <meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="keywords" content="">
    <link rel="shortcut icon" type="image/x-icon" href=""/>
    <title>
        <?php if(isset($PageTitle)): ?>
            <?php echo e($PageTitle); ?>

        <?php else: ?>
        ورود به پنل مدیریتی سایت
        <?php endif; ?>
    </title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link id="style" href="<?php echo e(asset('back-end/plugins/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('back-end/css/style.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('back-end/css/dark-style.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('back-end/css/transparent-style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('back-end/css/skin-modes.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('back-end/css/icons.css')); ?>" rel="stylesheet"/>
    <link id="theme" rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('back-end/colors/color1.css')); ?>"/>
    <link href="<?php echo e(asset('back-end/switcher/css/switcher.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('back-end/switcher/demo.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('back-end/fonts/iran-yekan.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('back-end/css/rtl.css')); ?>" rel="stylesheet"/>
    <script src="<?php echo e(asset('back-end/js/jquery.min.js')); ?>"></script>
    <!--My Custom Page Script-->


</head>
<script>
    var $baseUrl = '<?php echo e(url("/")); ?>';
</script>
<?php echo $__env->yieldContent('headScript'); ?>
<!-- end::Head -->
<!-- begin::Body -->
<body class="login-img rtl">


<div class="page">
<?php echo $__env->yieldContent('content' , 'No Content'); ?>
</div>

</body>
</html>
<?php /**PATH /var/www/html/resources/views/back-end/layouts/MasterLayoutError.blade.php ENDPATH**/ ?>