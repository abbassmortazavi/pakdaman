<h1>Error 400</h1>
<?php /**PATH /var/www/html/resources/views/errors/404.blade.php ENDPATH**/ ?>