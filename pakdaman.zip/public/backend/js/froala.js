new FroalaEditor('#editor',{
    // language: 'fa'
    language: 'fa'
});
