(function (e) {
    'use strict';
    $('#summernote').summernote({
        lang: "fa-IR"
    });
})();